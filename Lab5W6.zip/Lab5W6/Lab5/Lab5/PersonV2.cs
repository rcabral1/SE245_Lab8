﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    public class PersonV2
    {
        private string fName;
        private string mName;
        private string lName;
        private string address1;
        private string address2;
        private string phone;
        private string city;
        private string state;
        private string zip;
        private string email;
        private string facebook;

        protected string feedback;
        public string Fname
        {
            get { return fName; }
            set { fName = value; }
        }
        public string Mname
        {
            get { return mName; }
            set { mName = value; }
        }
        public string Lname
        {
            get { return lName; }
            set { lName = value; }
        }
        public string Address1
        {
            get { return address1; }
            set { address1 = value; }
        }
        public string Address2
        {
            get { return address2; }
            set { address2 = value; }
        }
        public string Phone
        {
            get { return phone; }
            set
            {
                if (Lab5.Validation.checkPhone(value) == true)
                {
                    phone = value;
                }

                else
                {
                    phone = "Invalid...Please enter 10 digits";
                }
            }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public string State
        {
            get { return state; }
            set
            {
                if (Lab5.Validation.checkState(value) == true)
                {
                    state = value;
                }

                else
                {
                    state = "Invalid...Please enter 2 Letters";
                }
            }
        }

        public string Zip
        {
            get { return zip; }

            set
            {
                if (Lab5.Validation.checkZip(value) == true)
                {
                    zip = value;
                }

                else
                {
                    zip = "Invalid...Please enter 5 Numbers";
                }

            }
        }


        public string Email
        {
            get { return email; }
            set
            {
                if (Lab5.Validation.checkEmail(value) == true)
                {
                    email = value;
                }

                else
                {
                    feedback += "ERROR: Invalid Email";
                }
            }

        }
        public string Facebook
        {
            get { return facebook; }
            set { facebook = value; }
        }

        public string Feedback
        {
            get { return feedback; }
        }


        public PersonV2()
        {
            fName = "";
            mName = "";
            lName = "";
            address1 = "";
            address2 = "";
            phone = "";
            city = "";
            state = "";
            zip = "";
            email = "";
            facebook = "";

            feedback = "";
    }
    }
}

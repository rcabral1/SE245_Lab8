﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Validation
    {
        public static bool checkState(string temp)
        {
            bool result = true;

            if (temp.Length != 2)
            {
                result = false;
            }

            return result;
        }



        public static bool checkZip(string temp)
        {
            bool result = true;

            if (temp.Length != 5)
            {
                result = false;
            }

            return result;
        }

        public static bool checkEmail(string temp)
        {
            bool result = true;

            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            int periodLocation = temp.LastIndexOf(".");
            if (temp.Length < 8)
            {
                result = false;
            }
            else if (atLocation < 2)
            {
                result = false;
            }

            else if (periodLocation + 2 > (temp.Length))
            {
                result = false;
            }
            return result;
        }

        public static bool checkPhone(string temp)
        {
            bool result = true;

            if (temp.Length < 10)
            {
                result = false;
            }

            return result;
        }

        public static bool checkDate(DateTime temp)
        {
            bool result;

            if (temp <= DateTime.Now)
            {
                result = false;
            }

            else
            {
                result = true;
            }

            return result;
        }


        public static bool checkDiscount(string temp)
        {
            bool result;

            if (temp.ToLower() == "yes")
            {
                result = true;
            }

            else
            {
                result = false;

            }

            return result;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        public Form1(int intPersonID)
        {
            InitializeComponent();
            Customer temp = new Customer();
            SqlDataReader dr = temp.FindOnePerson(intPersonID);

            while (dr.Read())
            {
                label16.Text = dr["PersonID"].ToString();
                txtFname.Text = dr["FirstName"].ToString();
                txtMname.Text = dr["MiddleName"].ToString();
                txtLname.Text = dr["LastName"].ToString();
                txtAddress1.Text = dr["Street1"].ToString();
                txtAddress2.Text = dr["Street2"].ToString();
                txtCity.Text = dr["City"].ToString();
                txtState.Text = dr["State"].ToString();
                txtZip.Text = dr["Zip"].ToString();
                txtPhone.Text = dr["Phone"].ToString();
                txtFacebook.Text = dr["Facebook"].ToString();
                txtEmail.Text = dr["Email"].ToString();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer temp = new Lab5.Customer();


           string strFeedback = "";
            Console.WriteLine(strFeedback);


            //Fill person variable/object
            temp.Fname = txtFname.Text;
            temp.Mname = txtMname.Text;
            temp.Lname = txtLname.Text;
            temp.Address1 = txtAddress1.Text;
            temp.Address2 = txtAddress2.Text;
            temp.Phone = txtPhone.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Zip = txtZip.Text;
            temp.Email = txtEmail.Text;
            temp.Facebook = txtFacebook.Text;
            temp.TotalPurchases = double.Parse(dblTotalPurchases.Text);
            temp.DiscountMember = (Validation.checkDiscount(txtDiscount.Text));
            temp.RewardsEarned = int.Parse(txtRewards.Text);
            //temp.CustomerSince = DateTime.Parse(txtCustomerSince.Text);

            //Output what we stored
            lblFeedBack.Text = " First Name: " + temp.Fname + "\n Middle Name: " + temp.Mname + "\n Last Name: " + temp.Lname + "\n Address 1: " + temp.Address1 + "\n Address 2: " + temp.Address2 + "\n Phone: " + temp.Phone + "\n City: " + temp.City + "\n State: " + temp.State + "\n Zip: " + temp.Zip + "\n Email: " + temp.Email + "\n Facebook: " + temp.Facebook + "\n Total Purchases:" + temp.TotalPurchases + "\n Discount Member:" + temp.DiscountMember + "\n Rewards Earned:" + temp.RewardsEarned + "\n Customer Since:" + temp.CustomerSince;


            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedBack.Text = temp.addRecord();

            }

            else
            {
                lblFeedBack.Text = temp.Feedback;
            }
        }

        //Delete person record
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Int32 PersonID = Convert.ToInt32(label16.Text);

            Customer temp = new Customer();

            lblFeedBack.Text = temp.DeletePerson(PersonID);
        }

        //Update person record
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Customer temp = new Lab5.Customer();

            //gather strings from form and set in object
            temp.Fname = txtFname.Text;
            temp.Mname = txtMname.Text;
            temp.Lname = txtLname.Text;
            temp.Address1 = txtAddress1.Text;
            temp.Address2 = txtAddress2.Text;
            temp.Phone = txtPhone.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Zip = txtZip.Text;
            temp.Email = txtEmail.Text;
            temp.Facebook = txtFacebook.Text;
            temp.PersonID = Convert.ToInt32(label16.Text);

            if(!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedBack.Text = temp.UpdateARecord();
            }
            else
            {
                lblFeedBack.Text = temp.Feedback;
            }
        }
        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void txtTotalPurchases_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void lblFeedBack_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }
    }
}

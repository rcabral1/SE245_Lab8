﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;

namespace Lab5
{
    public class Person
    {
        private string fName;
        private string mName;
        private string lName;
        private string address1;
        private string address2;
        private string phone;
        private string city;
        private string state;
        private string zip;
        private string email;
        private string facebook;

        protected string feedback;
        public string Fname
        {
            get { return fName; }
            set { fName = value; }
        }
        public string Mname
        {
            get { return mName; }
            set { mName = value; }
        }
        public string Lname
        {
            get { return lName; }
            set { lName = value; }
        }
        public string Address1
        {
            get { return address1; }
            set { address1 = value; }
        }
        public string Address2
        {
            get { return address2; }
            set { address2 = value; }
        }
        public string Phone
        {
            get { return phone; }
            set
            {
                if (Lab5.Validation.checkPhone(value) == true)
                {
                    phone = value;
                }

                else
                {
                    phone = "Invalid...Please enter 10 digits";
                }
            }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public string State
        {
            get { return state; }
            set
            {
                if (Lab5.Validation.checkState(value) == true)
                {
                    state = value;
                }

                else
                {
                    state = "Invalid...Please enter 2 Letters";
                }
            }
        }

        public string Zip
        {
            get { return zip; }

            set
            {
                if (Lab5.Validation.checkZip(value) == true)
                {
                    zip = value;
                }

                else
                {
                    zip = "Invalid...Please enter 5 Numbers";
                }

            }
        }


        public string Email
        {
            get { return email; }
            set
            {
                if (Lab5.Validation.checkEmail(value) == true)
                {
                    email = value;
                }

                else
                {
                    email = "Invalid...Please enter 8 Letters";
                }
            }

        }
        public string Facebook
        {
            get { return facebook; }
            set { facebook = value; }
        }

        public string Feedback
        {
            get { return feedback; }
        }

        public string addRecord()
        {
            string result = "";

            return result;
        }
        public Person()
        {
            fName = "";
            mName = "";
            lName = "";
            address1 = "";
            address2 = "";
            phone = "";
            city = "";
            state = "";
            zip = "";
            email = "";
            facebook = "";

            feedback = "";
        }

        public DataSet PeopleSearch(string strFirst, string strLast)
        {
            //Create dataset
            DataSet ds = new DataSet();
            //Create command for sql statement
            SqlCommand comm = new SqlCommand();
            //Write select statement
            String SQL = "SELECT personID, FirstName, MiddleName, LastName, Street1, Street2, City, State, Zip, Phone FROM Customers WHERE 0=0";

            //If first and last name are filled in

            if (strFirst.Length > 0)
            {
                SQL += " AND firstName LIKE @FirstName";
                comm.Parameters.AddWithValue("@FirstName", "%" + strFirst + "%");
            }

            if (strLast.Length > 0)
            {
                SQL += " AND lastName LIKE @LastName";
                comm.Parameters.AddWithValue("@LastName", "%" + strLast + "%");
            }

            //Creating DB tools
            //===========================================================================================
            SqlConnection conn = new SqlConnection(@"Server=sql.neit.edu,4500;Database=SE245_RCabral;User Id=SE245_RCabral;Password=008003309;");

            comm.Connection = conn;
            comm.CommandText = SQL;

            //Create the adapter
            SqlDataAdapter Da = new SqlDataAdapter();
            Da.SelectCommand = comm;

            //Get data
            conn.Open();
            Da.Fill(ds, "Customers_Temp");
            conn.Close();

            //Return data
            return ds;

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Customer : PersonV2
    {
        private DateTime customerSince;
        private Double totalPurchases;
        private bool discountMember;
        private int rewardsEarned;

        private int personID;
        public DateTime CustomerSince
        {
            get
            {
                return customerSince;
            }

            set
            {
                if (Validation.checkDate(value))
                {
                    customerSince = value;
                }

                else
                {
                    feedback += "\nERROR: You must enter future dates";
                }
            }
        }

        public bool DiscountMember
        {
            get { return discountMember; }
            set {
               // bool myBool = Convert.ToBoolean(value);
                discountMember = value;


            }
        }

        public Double TotalPurchases
        {
            get { return totalPurchases; }
            set { totalPurchases = value; }
        }




        public int RewardsEarned
        {
            get { return rewardsEarned; }
            set { rewardsEarned = value; }
        }

        public Int32 PersonID
        {
            get
            {
                return personID;
            }
            set
            {
                if(value >= 0)
                {
                    personID = value;
                }
                else
                {
                    feedback += "\nERROR: you have entered an invalid person ID";
                }
            }
        }

    //Connect to the server and add a record
        public string addRecord()
        {
            string result = "";

            SqlConnection Conn = new SqlConnection();

            string Connect = Conn.ConnectionString = @"Server=sql.neit.edu\studentsql server, 4500;Database=SE245_RCabral; User Id=SE245_RCabral;Password=008003309";

            string strSQL = "INSERT INTO Customers (FirstName, MiddleName, LastName, Street1, Street2, Phone, City, State, Zip, Email, Facebook, TotalPurchase, DiscountMember, RewardsEarned) Values (@fName, @mName, @lname, @address1, @address2, @phone, @city, @state, @zip, @email, @facebook, @totalPurchases, @discountMember, @rewardsEarned)";
            //Set place holders for each value
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;
            comm.Parameters.AddWithValue("@fName", Fname);
            comm.Parameters.AddWithValue("@mName", Mname);
            comm.Parameters.AddWithValue("@lName", Lname);
            comm.Parameters.AddWithValue("@address1", Address1);
            comm.Parameters.AddWithValue("@address2", Address2);
            comm.Parameters.AddWithValue("@phone", Phone);
            comm.Parameters.AddWithValue("@city", City);
            comm.Parameters.AddWithValue("@state", State);
            comm.Parameters.AddWithValue("@zip", Zip);
            comm.Parameters.AddWithValue("@email", Email);
            comm.Parameters.AddWithValue("@facebook", Facebook);
            //comm.Parameters.AddWithValue("@customerSince", customerSince);
            comm.Parameters.AddWithValue("@totalPurchases", totalPurchases);
            comm.Parameters.AddWithValue("@discountMember", discountMember);
            comm.Parameters.AddWithValue("@rewardsEarned", RewardsEarned);


            try
            {
                Conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                result = $"SUCCES: Inserted {intRecs} records.";
                result = "SUCCESS: Connected";
                Conn.Close();
            }
            catch (Exception err)
            {
                result = "ERROR: " + err.Message;
            }
            finally
            {

            }

            return result;
            
        }

        public SqlDataReader FindOnePerson(int intPersonID)
        {
            //Create and initialize the tools needed
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //my string
            string strConn = GetConnected();

            //My Sql command string to pull up one person data
            string sqlString = "SELECT * FROM Customers WHERE PersonID = @PersonID;";

            //tell the connection object the who what where how
            conn.ConnectionString = strConn;

            //Give the command object info
            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@PersonID", intPersonID);

            //Open the Database connection and execute sql command
            conn.Open();

            return comm.ExecuteReader();
        }

        public string DeletePerson(int intPersonID)
        {
            Int32 intRecords = 0;
            string result = "";

            //Create and Initialize the DB Tools we need
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //My connection string
            string strConn = GetConnected();

            //My Sql command string to pull up one persons data
            string sqlString = "DELETE FROM Customers WHERE PersonID = @PersonID;";

            //Tell the connection object the who,what, where,how
            conn.ConnectionString = strConn;

            //Give the command object info
            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@PersonID", intPersonID);

            try
            {
                //open connection
                conn.Open();

                //run the delete
                intRecords = comm.ExecuteNonQuery();
                result = intRecords.ToString() + " Records Deleted.";

            }
            catch (Exception err)
            {
                result = "ERROR: " + err.Message;
            }
            finally
            {
                //close connection
                conn.Close();
            }

            return result;
        }

        public string UpdateARecord()
        {
            Int32 intRecords = 0;
            string result = "";

            //Create SQL command string
            string strSQL = "UPDATE Customers SET FirstName=@FirstName, MiddleName=@MiddleName, LastName=@LastName, Street1=@Street1, Street2=@Street2, Phone=@Phone, City=@City, State=@State, Zip=@Zip, Email=@Email, Facebook=@Facebook,  TotalPurchase=@TotalPurchases, DiscountMember=@DiscountMember, RewardsEarned=@RewardsEarned WHERE PersonID = @PersonID;";

            // Create a connection to DB
            SqlConnection conn = new SqlConnection();
            //Create the who, what where of the DB
            string strConn = GetConnected();
            conn.ConnectionString = strConn;

            // Bark out our command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;  //Commander knows what to say
            comm.Connection = conn;     //Where's the phone?  Here it is

            //Fill in the paramters (Has to be created in same sequence as they are used in SQL Statement)
            comm.Parameters.AddWithValue("@FirstName", Fname);
            comm.Parameters.AddWithValue("@MiddleName", Mname);
            comm.Parameters.AddWithValue("@LastName", Lname);
            comm.Parameters.AddWithValue("@Street1", Address1);
            comm.Parameters.AddWithValue("@Street2", Address2);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Facebook", Facebook);
            //comm.Parameters.AddWithValue("@CustomerSince", customerSince);
            comm.Parameters.AddWithValue("@TotalPurchases", totalPurchases);
            comm.Parameters.AddWithValue("@DiscountMember", discountMember);
            comm.Parameters.AddWithValue("@RewardsEarned", RewardsEarned);
            comm.Parameters.AddWithValue("@PersonID", PersonID);


            try
            {
                //Open the connection
                conn.Open();

                //Run the Update and store the number of records effected
                intRecords = comm.ExecuteNonQuery();
                result = intRecords.ToString() + " Records Updated.";
            }
            catch (Exception err)
            {
                result = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {
                //close the connection
                conn.Close();
            }

            return result;

        }

        private string GetConnected()
        {
            return "Server=sql.neit.edu\\studentsql server, 4500; Database = SE245_RCabral; User Id = SE245_RCabral; Password = 008003309";
        }
    }
}

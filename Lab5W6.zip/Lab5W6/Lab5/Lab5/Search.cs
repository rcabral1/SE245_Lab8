﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            //retrieve data
            Person temp = new Person();
            //Do search
            DataSet ds = temp.PeopleSearch(textBox1.Text, textBox2.Text);

            //Display

            dgvResults.DataSource = ds;
            dgvResults.DataMember = ds.Tables["Customers_Temp"].ToString();


        }
        private void dgvResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPersonID = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();

            //display data
            MessageBox.Show(strPersonID);

            //convert string to int
            int intPersonID = Convert.ToInt32(strPersonID);

            Form1 Editor = new Form1(intPersonID);
            Editor.ShowDialog();
        }
        private void Search_Load(object sender, EventArgs e)
        {

        }

        private void dgvResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPersonID = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();

            //display data
            MessageBox.Show(strPersonID);

            //convert string to int
            int intPersonID = Convert.ToInt32(strPersonID);

            Form1 Editor = new Form1(intPersonID);
            Editor.ShowDialog();
        }
    }
}
